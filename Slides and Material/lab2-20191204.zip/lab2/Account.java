package lab2;

public class Account  {
    int bal=1000;
    public void diposit(){
        bal += 10;
    }
    public void withdraw(){
        bal -= 10;
    }
}
