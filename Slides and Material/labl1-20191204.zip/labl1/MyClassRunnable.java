package labl1;

public class MyClassRunnable implements Runnable {
    @Override
    public void run() {
        System.out.println("I am thread: " + Thread.currentThread().getName());
    }
}
