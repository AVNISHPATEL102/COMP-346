package labl1;

public class AnonymousThread {
    public static void main(String[] argv){
        System.out.println("Name: " + Thread.currentThread().getName());
        Thread t = new Thread(){
            public void run() {
                System.out.println("Hi I am thread");
                System.out.println("Name: " + Thread.currentThread().getName());
            }
        };
        t.start();
    }
}
