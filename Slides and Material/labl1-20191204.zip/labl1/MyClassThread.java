package labl1;

public class MyClassThread extends Thread {
    public void run(){
        System.out.println("I am thread: " + Thread.currentThread().getName());
    }
}