package labl1;

public class MyMain {
    public static void main (String[] argv){
        System.out.println("I am thread: " + Thread.currentThread().getName());
        MyClassThread obj1 = new MyClassThread();
        obj1.start();

        MyClassRunnable obj2 = new MyClassRunnable();
        Thread t1 = new Thread(obj2);
        t1.start();
        new Thread(obj2).start();
        new Thread(obj2).start();
        new Thread(obj2).start();
    }
}
